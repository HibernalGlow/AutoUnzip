# Notes
A markdown file that does not mention the magic word.